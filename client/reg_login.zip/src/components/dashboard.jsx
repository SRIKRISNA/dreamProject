
function Dashboard(){
    return(
        <>
            <h1>Hello Dash</h1>
        </>
    )
}
export default Dashboard;